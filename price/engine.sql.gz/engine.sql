-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2024 at 11:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `engine`
--

-- --------------------------------------------------------

--
-- Table structure for table `search_engine`
--

CREATE TABLE `search_engine` (
  `id` int(255) NOT NULL,
  `title` varchar(250) NOT NULL,
  `url` text NOT NULL,
  `keywords` text NOT NULL,
  `price` int(200) NOT NULL,
  `rating` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `search_engine`
--

INSERT INTO `search_engine` (`id`, `title`, `url`, `keywords`, `price`, `rating`) VALUES
(1, 'Poco X4 Pro', 'https://www.poco.in/pocox4pro5Gspec', 'POCOx4Pro m4pro m4 pro POCO poco pro\r\n', 0, '0'),
(2, 'Vivo v20 Pro', 'https://www.vivo.com/en/products/param/v20pro', 'v20pro vivo v20 pro ', 0, '0'),
(3, 'Samsung S20 Fe', 'https://www.samsung.com/in/smartphones/galaxy-s20/buy/', 's20 samsung s20fe Samsung s20 FE fe s S', 29999, '4.1/5'),
(4, 'Samsung S22 Plus', 'https://www.samsung.com/in/smartphones/galaxy-s22/buy/', 'SamsungS22plus s22 s22+ plus Plus s S', 62999, '4.3/5'),
(5, 'Samsung S22 Ultra', 'https://www.samsung.com/in/smartphones/galaxy-s22-ultra/buy/\r\n', 's22 s22ultra ultra samsung Samsung s S', 117999, '4.4/5'),
(6, 'Samsung S23', 'https://www.samsung.com/in/smartphones/galaxy-s23/buy/', 's23 Samsungs23 samsung Samsung s S', 79999, '4.4/5'),
(7, 'Samsung S23 Plus', 'https://www.samsung.com/in/smartphones/galaxy-s23/buy/', 'samsung s23 plus', 94999, '4.0/5'),
(8, 'Samsung S22', 'https://www.samsung.com/in/smartphones/galaxy-s22/buy/', 'Samsung s22 samsungs22 SamsungS22', 39999, '4.1/5'),
(9, 'Samsung S23 Ultra', 'https://www.samsung.com/in/smartphones/galaxy-s23-ultra/buy/', 's23 ultra SamsungS23ultra S23 samsung Samsung', 124999, '4.6/5'),
(10, 'Samsung S21 Fe', 'https://www.samsung.com/in/smartphones/galaxy-s21-5g/galaxy-s21-fe-5g/buy/', 's21 samsungs21fe fe Samsung samsungs21 samsung', 31999, '4.1/5'),
(11, 'Samsung S21 Fe(Special Edition)', 'https://www.samsung.com/in/smartphones/galaxy-s23-fe/buy/', 'SamsungS21 s21fe fe SpecialEdition samsung ', 54999, '3.9/5'),
(12, 'Samsung S23 Fe\r\n', 'https://www.samsung.com/in/smartphones/galaxy-s23-fe/buy/', 's23 fe s23fe samsung Samsung', 54999, '4.2/5'),
(13, 'Samsung Z Flip 4', 'https://www.samsung.com/in/smartphones/galaxy-z-flip4/buy/', 'Samsung samsung Z Flip samsungflip4', 59999, '3.8/5'),
(14, 'Samsung Fold 4', 'https://www.samsung.com/in/smartphones/galaxy-z-fold4/buy/', 'samsung Samsung samsungfold4 Fold4 fold4', 114999, '3/5'),
(15, 'Samsung Fold 5', 'https://www.samsung.com/in/smartphones/galaxy-z-fold5/buy/', 'Samsung samsung Samsungfold5 fold5 samsungfold5 ', 154999, '4.6/5'),
(16, 'Samsung F22', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f22-black-64gb-sm-e225fzkdins/buy/', 'samsungf22 f22 samsung ', 13499, '4.3/5'),
(17, 'Samsung F42', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f42-5g-blue-128gb-storage-6gb-ram-sm-e426bzbgins/buy/', 'samsungf42 F42 samung Samsung', 22499, '4.0/5\r\n'),
(18, 'Samsung F23', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f23-light-blue-128gb-storage-6gb-ram-sm-e236blbhins/buy/', 'samsungf23 f23 F23 samsung', 18499, '4.0/5'),
(19, 'Samsung F13', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f13-4gb-ram-awesomeblue-64gb-sm-e135flbdins/buy/', 'samsungf13 F13 samsung Samsung', 7499, '4.0/5'),
(20, 'Samsung F04', 'https://www.samsung.com/in/smartphones/galaxy-f/f04-green-64gb-sm-e045fzggins/buy/', 'Samsungf04 f04 samung Samsung ', 5999, '2.9/5'),
(21, 'Samsung F14', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f14-5g-black-128gb-sm-e146bzkhins/buy/', 'samsung Samsung Samsungf14 SamsungF14', 10499, '3.5/5'),
(22, 'Samsung F54', 'https://www.samsung.com/in/smartphones/galaxy-f/f54-awesome-silver-256gb-sm-e546bzshins/buy/', 'samsungf54 Samsung samsung f54', 24999, '3.9/5'),
(23, 'Samsung F34', 'https://www.samsung.com/in/smartphones/galaxy-f/galaxy-f34-black-128gb-sm-e346bzkhins/buy/', 'samsung Samsung f34 samsungf34', 15999, '4/5'),
(24, 'Samsung M12', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m12-blue-128gb-sm-m127gzbhins/buy/', 'Samsungm12 m12 Samsung', 13299, '3/5'),
(25, 'Samsung M32', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m32-blue-128gb-sm-m325flbcins/buy/', 'Samsungm32 m32 samsung', 18999, '3.8/5'),
(26, 'Samsung M52', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m52-5g-light-blue-128gb-storage-6gb-ram-sm-m526blbhinu/buy/', 'samsung samsungm52 m52', 24990, '4.1/5'),
(27, 'Samsung M33', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m33-5g-blue-128gb-storage-8gb-ram-sm-m336bzbrins/buy/', 'm33 samsungm33 samsung', 16990, '3.9/5'),
(28, 'Samsung M53', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m53-5g-green-128gb-storage-8gb-ram-sm-m536bzgfinu/buy/', 'samsung samsungm53 m53', 23990, '3.8/5'),
(29, 'Samsung M13', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m13-5g-forest-green-128gb-sm-m136blghins/buy/', 'samsung samungm13 m13', 9299, '3.8/5'),
(30, 'Samsung M14', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m14-5g-6gb-ram-blue-128gb-sm-m146bzbhins/buy/', 'samsung samsungm14 m14 ', 13499, '3.3/5'),
(31, 'Samsung M04', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m04-green-64gb-sm-m045flggins/buy/', 'samsung samungm04 m04', 7499, '3.2/5'),
(32, 'Samsung M34', 'https://www.samsung.com/in/smartphones/galaxy-m/galaxy-m34-5g-blue-128gb-sm-m346bzbdins/buy/', 'samsung samsungm34 m34', 16299, '3.8/5'),
(33, 'Samsung A52', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a52/buy/', 'samsung samsunga52 A52 a52', 24999, '4.0/5'),
(34, 'Samsung A22', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a22-5g-gray-128gb-sm-a226bzajins/buy/', 'samsung samsunga22 a22 A22', 17799, '3.4/5'),
(35, 'Samsung A03s', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a03s-blue-32gb-13mp-triple-camera-powerful-5000mah-battery-enhanced-security-with-side-fingerprint-sm-a037fzbdins/buy/', 'samsung samunga03s a03 A03s', 11099, '4/5'),
(36, 'Samsung A52s', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a52s-5g-awesome-black-128gb-storage-8gb-ram-sdm-77g-processor-120hz-fhd-plus-samoled-display-5g-guarantee-with-12-band-support-sm-a528bzkgins/buy/', 'Samsung a52s samsunga52s', 37999, '4.1/5'),
(37, 'Samsung A32', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a32-awesome-blue-128gb-storage-8gb-ram-sm-a325fzbiins/buy/', 'samsung samunga32 a32', 19990, '4/5'),
(38, 'Samsung A03 Core', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a03-core-black-32gb-sm-a032fckdins/buy/', 'samsung core a03 samsunga03', 6750, '4.1/5'),
(39, 'Samsung A33', 'https://www.samsung.com/in/smartphones/galaxy-a33/buy/', 'samsung samsunga33', 23999, '3.9/5'),
(40, 'Samsung A13', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a13-black-64gb-sm-a135fzkgins/buy/', 'samsung samunga13', 14999, '4/5'),
(41, 'Samsung A23', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a23-black-128gb-sm-a235fzkhins/buy/', 'samsung samsunga23', 21999, '3.9/5'),
(42, 'Samsung A53', 'https://www.samsung.com/in/smartphones/galaxy-a53/buy/', 'samsung samsunga53', 21999, '3.9/5'),
(43, 'Samsung A73', 'https://www.samsung.com/in/smartphones/galaxy-a73/buy/', 'samsung samsunga73', 32990, '4/5'),
(44, 'Samsung A04e', 'https://www.samsung.com/in/smartphones/galaxy-a/galaxy-a04e-light-blue-128gb-sm-a042flbkins/buy/', 'samsung samsunga04e', 41999, '4.1/5'),
(45, 'Samsung A54', 'https://www.samsung.com/in/smartphones/galaxy-a54/buy/', 'samsung samsunga54', 9998, '3.9/5'),
(46, 'Vivo X100', 'https://shop.vivo.com/in/product/10260?from=officialsite&_ga=2.114473479.1239747284.1705129882-557255431.1705129882&_gac=1.171765268.1705129882.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2achkovm%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEyOTg4NS41Ni4wLjA.', 'x100 vivo', 37499, '4.2/5'),
(48, 'vivo x100 Pro', 'https://shop.vivo.com/in/product/10261?from=officialsite&_ga=2.114856455.1239747284.1705129882-557255431.1705129882&_gac=1.48949906.1705129956.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2a1sdppzo%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEyOTk1OC41NC4wLjA.', 'vivo x100 pro', 89999, '4.5/5'),
(49, 'Vivo v29', 'https://shop.vivo.com/in/product/10255', 'vivo v29 ', 32999, '4.3/5'),
(50, 'Vivo V29e', 'https://shop.vivo.com/in/product/10252?from=officialsite&_ga=2.218150809.1239747284.1705129882-557255431.1705129882&_gac=1.246024880.1705129995.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2a17ndmg3%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEzMDI2Ny45LjAuMA..\r\n', 'vivo v29 v29e', 26999, '4.3/5'),
(51, 'Vivo V27', 'https://shop.vivo.com/in/product/10237?utm_source=vivoWebsite&utm_medium=prolist_V27&utm_campaign=vivo_V27&cid=vivoWebsite_homepage_V27&from=officialsite&_ga=2.109088901.1239747284.1705129882-557255431.1705129882&_gac=1.184156434.1705129995.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2aj8ofqq%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEzMDMzNi40Mi4wLjA.', 'vivo v27', 32999, '4.1/5'),
(52, 'Vivo V27 Pro', 'https://shop.vivo.com/in/product/10234?utm_source=vivoWebsite&utm_medium=homepage_bigbanner_V27Pro&utm_campaign=vivo_V27Pro&cid=vivoWebsite_homepage_bigbanner_V27Pro&from=officialsite&_ga=2.211342229.1239747284.1705129882-557255431.1705129882&_gac=1.8130182.1705129995.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2amznddn%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEzMDQ1OC40NC4wLjA.', 'vivo v27 pro', 36499, '4.2/5'),
(53, 'Vivo V29 Pro', 'https://shop.vivo.com/in/product/10256?from=officialsite&_ga=2.218150809.1239747284.1705129882-557255431.1705129882&_gac=1.246024880.1705129995.EAIaIQobChMIwtuc5OfZgwMVq0VIAB23BQa5EAAYASAAEgLs9fD_BwE&_gl=1%2a1ffv9uu%2a_ga%2aNTU3MjU1NDMxLjE3MDUxMjk4ODI.%2a_ga_68BLCXM546%2aMTcwNTEyOTg4MS4xLjEuMTcwNTEzMDIyMS41NS4wLjA.', 'vivo v29 pro', 42999, '4.5/5'),
(54, 'iPhone 15 Pro Max', 'https://www.apple.com/in/shop/buy-iphone/iphone-15-pro', 'iphone apple', 159990, '4.1/5\r\n'),
(55, 'iPhone 15 Pro ', 'https://www.apple.com/in/shop/buy-iphone/iphone-15-pro', 'iphone apple', 134990, '4.1/5\r\n'),
(56, 'iPhone 15', 'https://www.apple.com/in/shop/buy-iphone/iphone-15', 'iphone apple', 79900, '4/5'),
(57, 'iPhone 15 Plus', 'https://www.apple.com/in/shop/buy-iphone/iphone-15', 'iphone appple', 89900, '4.1/5'),
(58, 'iPhone 14', 'https://www.apple.com/in/shop/buy-iphone/iphone-14', 'iphone apple', 69900, '4.2/5'),
(59, 'iPhone 14 Plus', 'https://www.apple.com/in/shop/buy-iphone/iphone-14', 'iphone apple', 79900, '4.1/5'),
(60, 'iPhone 13', 'https://www.apple.com/in/shop/buy-iphone/iphone-13', 'iphone apple', 59990, '4.4/5'),
(61, 'iPhone SE', 'https://www.apple.com/in/shop/buy-iphone/iphone-se', 'iphone apple', 49990, '4/5'),
(62, 'OPPO Reno11 Pro 5G', 'https://www.oppo.com/in/product/oppo-reno11-5g.P.P1100151', 'oppo Reno reno', 39999, '4.5/5'),
(63, 'OPPO Reno11 5G', 'https://www.oppo.com/in/product/oppo-reno11-5g.P.P1100151', 'oppo reno', 29999, '4.2/5'),
(64, 'OPPO Reno10 Pro 5G', 'https://www.oppo.com/in/product/oppo-reno10-pro.P.P1100138', 'oppo reno pro', 37999, '4/5'),
(65, 'Oppo N3 Flip', 'https://www.oppo.com/in/product/oppo-find-n3-flip.P.P1100145', 'oppo flip', 94999, '4.2/5'),
(66, 'Oppo N2 flip', 'https://www.oppo.com/in/product/oppo-find-n2-flip.P.P1100126', 'oppo flip', 89999, '3.9/5'),
(67, 'Oppo F21s pro 5g', 'https://www.oppo.com/in/product/f21pro5g.P.P1100098', 'oppo pro f21', 21999, '4.5/5'),
(68, 'Oppo F21s pro ', 'https://www.oppo.com/in/product/oppo-f21spro.P.P1100116', 'oppo f21', 25999, '4.3/5'),
(69, 'Oppo F23 5G', 'https://www.oppo.com/in/product/f23-5g.P.P1100135', 'oppo f23 ', 22999, '3.8/5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `search_engine`
--
ALTER TABLE `search_engine`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `search_engine`
--
ALTER TABLE `search_engine`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
